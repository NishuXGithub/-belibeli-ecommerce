'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';

type CardType = {
  id: number;
  title: string;
  description: string;
  category: string;
  image: string;
  price: number;
  rating: {
    rate: number;
    count: number;
  };
};

function ProductDetail() {
  const params = useParams();
  const router = useRouter();

  const [product, setProduct] = useState<CardType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const id = params.id as string;

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);

        const res = await fetch(`https://fakestoreapi.com/products/${id}`);

        if (!res.ok) {
          throw new Error('Product not found');
        }

        const data: CardType = await res.json();
        setProduct(data);
      } catch (err) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('Something went wrong');
        }
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchProduct();
    }
  }, [id]);

  if (loading) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  if (error) {
    return (
      <div className="text-center mt-10">
        <p className="text-red-500 mb-4">
          Error: {error}
        </p>

     <Link href="/card" className="text-blue-600 underline">
          Go Back Products
        </Link>
      </div>
    );
  }

  if (!product) {
    return null;
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <button
        onClick={() => router.back()}
        className="mb-6 text-blue-600 hover:underline flex items-center gap-2"
      >
        ← Back to Products
      </button>

      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6 md:p-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gray-50 p-6 rounded-lg flex items-center justify-center">
            <img
              src={product.image}
              alt={product.title}
              className="max-h-96 object-contain"
            />
          </div>

          <div>
            <p className="text-sm font-semibold text-blue-600 uppercase mb-2">
              {product.category}
            </p>

            <h1 className="text-3xl font-bold mb-4">
              {product.title}
            </h1>

            <div className="flex items-center gap-2 mb-4">
              <span className="text-yellow-500 text-xl">★</span>

              <span className="font-semibold">
                {product.rating.rate}
              </span>

              <span className="text-gray-500">
                ({product.rating.count} reviews)
              </span>
            </div>

            <p className="text-4xl font-bold text-green-600 mb-6">
              ${product.price}
            </p>

            <h3 className="font-semibold text-lg mb-2">
              Description:
            </h3>

            <p className="text-gray-700 leading-relaxed mb-6">
              {product.description}
            </p>

            <button
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-semibold"
              onClick={() => alert('Added to cart!')}
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;