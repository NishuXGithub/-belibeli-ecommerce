'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

type CardType = {
  id: number;
  title: string;
  description: string;
  category: string;
  image: string;
  price: number;
  rating: {
    rate: number;
    count: number;
  };
};

function CardPage() {
  const [card, setCard] = useState<CardType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const res = await fetch('https://fakestoreapi.com/products');

        if (!res.ok) {
          throw new Error('Failed to fetch data');
        }

        const data: CardType[] = await res.json();
        setCard(data);
      } catch (err) {
        if (err instanceof Error) {
          setError(err.message);
        } else {
          setError('Something went wrong');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  if (error) {
    return (
      <p className="text-center mt-10 text-red-500">
        Error: {error}
      </p>
    );
  }

  return (
    

    <div className="p-6 bg-gray-50 min-h-screen">
      
<div className="flex item-center gap-35 mb-6 border bordeer-gray-300 p-4 justify-cenetr rounded-lg bg-whi"> 
<div>Home</div>
<div>Products</div>
<div>Categories</div>
<div>Search Bar</div>
<div>Cart</div>
<div><button>Add Cart</button></div>
</div>
      <h1 className="text-3xl font-bold text-center mb-8">
        Products
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
        {card.map((item) => (
          <Link
            href={`/card/${item.id}`}
            key={item.id}
            className="bg-white rounded-lg shadow-md p-4 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-200"
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-40 object-contain mb-3"
            />

            <h2 className="font-semibold text-lg line-clamp-1">
              {item.title}
            </h2>

            <p className="text-sm text-gray-500 capitalize">
              {item.category}
            </p>

            <p className="text-xl font-bold text-blue-600 mt-2">
              ${item.price}
            </p>

            <p className="text-sm mt-1">
              ⭐ {item.rating.rate}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default CardPage;